# Blood Donor Finder

A mobile app for finding and registering blood donors. Blood-red theme, Playfair Display + Inter typography.

## Features
- Welcome, Sign up, Log in (email + password, hashed with SHA-256)
- Home, Search donor (blood group / location / distance), Nearby donors, Donor profile
- Register as a donor, Request blood, My requests, Request details
- Notifications, My profile, Log out
- Admin dashboard (total users, total logins, logins today, 7-day chart, user list)

## Project structure
```
www/
  index.html            screens (markup)
  css/styles.css        design tokens + styles
  js/app.js             navigation, auth, donors, requests, admin
  manifest.webmanifest  PWA manifest
  sw.js                 offline cache
  icons/                app icons
capacitor.config.json   Android wrapper config
package.json
```

## Run in the browser
```
npm start        # or: npx serve www
```
Open the printed URL on your phone or desktop. It can be installed as an app (Add to Home screen) because it is a PWA.

## Build an Android APK
Requires Node 18+, JDK 17 and Android Studio.
```
npm install
npm run android:add
npm run android:sync
npm run android:open     # opens Android Studio
```
In Android Studio: Build > Build Bundle(s) / APK(s) > Build APK(s). For Play Store use Build > Generate Signed Bundle (AAB).
After any change in `www/`, run `npm run android:sync` again.

## Admin login
Email `admin@blooddonor.app`, password `Admin@123` (constants `ADMIN` in `www/js/app.js`).

## Important notes
- Accounts, requests and login counts are stored in the device's localStorage. The admin dashboard therefore counts only users of the same device. For production, replace the storage functions (`ld` / `sv` in `app.js`) with calls to a backend (Firebase, Supabase or your own API) and move admin authentication to the server.
- Donors, notifications and the Call/Chat buttons use sample data and placeholder actions.
